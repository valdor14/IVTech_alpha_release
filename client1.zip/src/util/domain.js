const domain = "http://localhost:5000";
export default domain;