import React, { useContext, useState } from "react";
//import "./Event.scss";
import { useTranslation } from "react-i18next";
import domain from "../../util/domain";
import axios from "axios";
import UserContext from "../../context/UserContext";
import "./NewHome.scss"
import logo from "./images/mock_logo2.jpeg"

function NewHome(){
    return(
        <div class="body1">

    <header>
        <div class="landing-text">
            <h1>IVTech</h1>
            <h6>Engineering & Technology Club</h6>
        </div>
    </header>

    <section class = "about" id="about">
        <div class="container">
            <div class="profile-img" data-aos="fade-right" data-aos-delay="300">
                <img src="images/mock_logo2.jpeg" alt=""/>
            </div>
            <div class="about-details" data-aos="fade-left" data-aos-delay="600">
                <div class="about-heading">
                    <h1>About</h1>
                    <h6>Us</h6>
                </div>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <div class="social-media">
                <ul class="nav-list">
                    <li>
                        <a href="#" class="icon-link">
                            <i class="fab fa-facebook-square"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="icon-link">
                            <i class="fab fa-twitter-square"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="icon-link">
                            <i class="fab fa-dribbble-square"></i>
                        </a>
                    </li>
                </ul>
            </div>
            </div>
        </div>
    </section>


    <section class="services" id="services">
        <div class="container">
            <div class="section-heading">
                <h1>Services</h1>
                <h6>What can we do for you</h6>
            </div>
            <div class="my-skills">
                <div class="skill" data-aos="fade-in" data-aos-delay="300">
                    <div class="icon-container">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <h1>Tech Training</h1>
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
            </div>
            <div class="my-skills">
                <div class="skill" data-aos="fade-in" data-aos-delay="600">
                    <div class="icon-container">
                        <i class="fas fa-code"></i>
                    </div>
                    <h1>Software Development</h1>
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
            </div>
            <div class="my-skills">
                <div class="skill" data-aos="fade-in" data-aos-delay="900">
                    <div class="icon-container">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h1>Career Opportunities</h1>
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
            </div>
        </div>
    </section>

     <section class="portofolio" id="portofolio">
        <div class="container">
            <div class="section-heading">
                <h1>Portofolio</h1>
                <h6>View some of our members recent work</h6>
            </div>
            <div class="portofolio-item">
                <div class="portofolio-img has-margin-right" data-aos="fade-right" data-aos-delay="300">
                    <img src="images/portitem1.jpeg" alt=""/>
                </div>
                <div class="portofolio-description" data-aos="fade-left" data-aos-delay="600">
                    <h6>Web Development</h6>
                    <h1>Blog Website</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <a href="#" class="cta">View Details</a>
                </div>
            </div>
            <div class="portofolio-item">
                <div class="portofolio-description has-margin-right" data-aos="fade-right" data-aos-delay="900">
                    <h6>Web Design</h6>
                    <h1>Product Layout</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <a href="#" class="cta">View Details</a>
                </div>
                <div class="portofolio-img" data-aos="fade-left" data-aos-delay="1200">
                    <img src="images/portitem2.jpeg" alt=""/>
                </div>
            </div>
            <div class="portofolio-item">
                <div class="portofolio-img has-margin-right" data-aos="fade-right" data-aos-delay="1500">
                    <img src="images/portitem3.jpeg" alt=""/>
                </div>
                <div class="portofolio-description" data-aos="fade-left" data-aos-delay="1800">
                    <h6>Web Design</h6>
                    <h1>Product Sketch</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <a href="#" class="cta">View Details</a>
                </div>
            </div>
        </div>
    </section>


    <section class="experience" id="experience">
        <div class="container">
            <div class="section-heading">
                <h1>Our Story</h1>
                <h6>How it all started</h6>
            </div>
            <div class="timeline" data-aos="fade-down" data-aos-delay="300">
                <ul>
                    <li class="date" data-date="2020 - Present">
                        <h1>First</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                    </li>
                    <li class="date" data-date="2019 - 2020">
                        <h1>Second</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                    </li>
                    <li class="date" data-date="2017 - 2019">
                        <h1>Third</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <section class="contact" id="contact">
        <div class="container">
            <div class="section-heading">
                <h1>Contact</h1>
                <h6>Let's work together</h6>
            </div>
            <form action="" data-aos="fade-up" data-aos-delay="300">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter your name..." required/>
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" placeholder="Enter your email..." required/>
                <label for="services">Services:</label>
                <select name="services" id="service">
                    <option value="">Web Design</option>
                    <option value="">Web Development</option>
                     <option value="">Web Development/Design</option>
                </select>
                <label for="subject">Subject:</label>
                <textarea name="subject" id="subject" cols="10" rows="10"></textarea>
                <input type="submit" value="Submit"/>
            </form>
        </div>
    </section>
    </div>

    )
}

export default NewHome;