import React, { useState, useEffect, useContext } from "react";
//import "./Event.scss";
import { useTranslation } from "react-i18next";
import domain from "../../util/domain";
import axios from "axios";
import UserContext from "../../context/UserContext";
import "./Mentor.scss";


// destructuring props into event
function Mentor({ mentor, getMentors, editMentor }) {

  const { t } = useTranslation();
  const { user } = useContext(UserContext);
  const [role, setRole] = useState();


  async function deleteMentor() {
    if (window.confirm("Do you want to delete this mentor?")) {
      await axios.delete(`${domain}/mentors/${mentor._id}`);
      getMentors();
    }
  }

  async function getRole() {
    const role = await axios.get(`${domain}/auth/role/${user}`);
    setRole(role.data);
    return role.data;
  }

  getRole();

  return (
    <div className='mentor'>
      {mentor.title && <h2 className='title'>[TITLU] {mentor.title}</h2>}
      {mentor.description && (
        <pre className='description'>
          <p>[DESCRIERE] {mentor.description}</p>
        </pre>
      )}
      {mentor.image && (
        <pre className='image'>
          <img src={mentor.image} alt="" width="500" height="500"></img>
        </pre>
      )}
      {(role === "Support" || role ==="Admin") && (
        <>
      <button className='btn-edit' onClick={() => editMentor(mentor)}>
        {t("Edit")}
      </button>
      <button className='btn-delete' onClick={deleteMentor}>
        {t("Delete")}
      </button>
      </>
      )}
    </div>
  );
}

export default Mentor;