import axios from "axios";
import React from "react";
import { UserContextProvider } from "./context/UserContext";
import Router from "./Router";
import "./style/index.scss";
import LanguageSelect from "./languageSelect";
import Particles from "./components/particles/Particles";

axios.defaults.withCredentials = true;

function App() {

  return (
    <UserContextProvider>
      <div style={{position:"fixed", top:0, left: 0, right: 0, height:"100%"}}>
        <Particles />
      </div>
      <div className="language-select">
        <LanguageSelect />
      </div>
      <div className='container' style={{position: "relative"}}>
        <Router />
      </div>
      <div style={{position:"relative",bottom:0,width:"100%", minHeight: "10vh", background: "Orange"}}>
        TODO FOOTER
      </div>
    </UserContextProvider>
  );
}

export default App;
