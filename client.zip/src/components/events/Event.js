import React, { useContext, useState } from "react";
//import "./Event.scss";
import { useTranslation } from "react-i18next";
import domain from "../../util/domain";
import axios from "axios";
import UserContext from "../../context/UserContext";

// destructuring props into event
function Event({ event, getEvents, editEvent }) {

  const { t } = useTranslation();
  const { user, getUser } = useContext(UserContext);
  const [role, setRole] = useState();

  async function deleteEvent() {
    if (window.confirm("Do you want to delete this event?")) {
      await axios.delete(`${domain}/events/${event._id}`);
      getEvents();
    }
  }

  async function getRole() {
    const role = await axios.get(`${domain}/auth/role/${user}`);
    setRole(role.data);
    return role.data;
  }

  getRole();

  var dispDate = event.date;
  var cdate = (new Date(dispDate)).toString();
  return (
    <div className='event' style={{background: "white"}}>
      {event.title && <h2 className='title'>[TITLU] {event.title}</h2>}
      {event.date && (
        <p className='date'>[DATA] {cdate}</p>
      )}
      {event.description && (
        <pre className='description'>
          <p>[DESCRIERE] {event.description}</p>
        </pre>
      )}
      {event.location && (
        <pre className='location'>
          <p>[LOCATIE] {event.location}</p>
        </pre>
      )}
      {event.image && (
        <pre className='image'>
          <img src={event.image} alt="" width="500" height="500"></img>
        </pre>
      )}
      {(role === "Support" || role === "Admin") && (
        <>
      <button className='btn-edit' onClick={() => editEvent(event)}>
        {t("Edit")}
      </button>
      <button className='btn-delete' onClick={deleteEvent}>
        {t("Delete")}
      </button>
      </>
      )}
    </div>
  );
}

export default Event;
