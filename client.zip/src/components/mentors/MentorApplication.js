import axios from "axios";
import React, {useState} from "react";
//import "./Event.scss";
import { useTranslation } from "react-i18next";

// destructuring props into event
function MentorApplication() {

  const { t } = useTranslation();


    const [data, setData] = useState({
        name: "",
        contact: "",
        mentor: "",
        motivation: ""
    })

const onSubmit = async (e) => {
    e.preventDefault();
    try{
        await axios.post("http://localhost:5000/mentors/application", {
            name: data.name,
            contact: data.contact,
            mentor: data.mentor,
            motivation : data.motivation
        })
    }catch (error){
        console.log(error)
    }
}

function handle (e) {
    const newData={...data}
    newData[e.target.id] = e.target.value
    setData(newData)
    console.log(newData)
}


  return (
    <div>
        <form onSubmit = {(e) => onSubmit(e)}>
            <input onChange={(e) => handle(e)} id="name" value={data.name} placeholder="Name" type="text"></input>
            <textarea onChange={(e) => handle(e)} id="contact" value={data.contact} placeholder="Contact" type="text"></textarea>
            <input onChange={(e) => handle(e)} id="mentor" value={data.mentor} placeholder="Mentor" type="text"></input>
            <textarea onChange={(e) => handle(e)} id="motivation" value={data.motivation} placeholder="Motivation" type="text"></textarea>
            <button>Submit</button>
        </form>
    </div>
  );
}

export default MentorApplication;