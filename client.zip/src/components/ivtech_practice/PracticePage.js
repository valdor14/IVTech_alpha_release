import axios from "axios";
import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import UserContext from "../../context/UserContext";
import domain from "../../util/domain";
import { useTranslation } from "react-i18next";



function PracticePage() {
  const { t } = useTranslation();


  return (
    <div className='practicePage'>
      <Link to='interview'>
        <h1>{t("Interview")}</h1>
      </Link>
      <Link to='compiler'>
        <h1>{t("Online Compiler")}</h1>
      </Link>
      <Link to='apis'>
        <h1>{t("APIs")}</h1>
      </Link>
      <Link to='snippets'>
        <h1>{t("Snippets")}</h1>
      </Link>
    </div>
  );
}

export default PracticePage;