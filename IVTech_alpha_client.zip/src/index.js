import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./i18nextInit";
//import collection from 'easter-egg-collection';
ReactDOM.render(<App />, document.getElementById("root"));
